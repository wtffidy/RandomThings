{
  "python.analysis.extraPaths": [
    "./Skua Roulette"
  ]
}
